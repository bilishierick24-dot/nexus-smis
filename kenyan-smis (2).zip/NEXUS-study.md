# NEXUS Archive Study — Kenyan SMIS

## Executive finding

The NEXUS archive is a static browser export of a school-management application. It contains 13 HTML screen snapshots, repeated copies of one bundled CSS file and one bundled JavaScript file, and an effectively empty `prompt.txt`. It does not contain backend source, database migrations, API credentials, or a reusable component source tree.

The archive is nevertheless valuable as a product-reference library for expanding the existing Kenyan SMIS prototype, particularly in academics, user administration, institutional configuration, and learner records preservation.

## Distinct modules identified

| Area | NEXUS capability observed | Relevance to current SMIS |
| --- | --- | --- |
| Assessments | CBC 8-level marklists with Mid Term, End Term, and related assessment columns | High-priority enhancement to the current Academics view |
| Teacher allocations | Assign teachers to grades/classes and learning areas; restrict visibility to assigned subjects and grades | Important role-based authorization rule |
| Users | Registered-user directory, roles, status, contact fields, and credential/access configuration | Useful administrative workflow, but must be implemented with secure password hashing and never expose credential hashes in routine UI |
| School settings | School identity, motto, contacts, logo, term/year, signatures, stamp, report-card options | Strong basis for report-card configuration |
| Report cards | Configurable headers and optional fee/balance visibility | Useful for CBC/JSS report generation |
| Finance | Fees, payments, accountability, and store-keeping navigation | Confirms need for deeper bursar workflows beyond the current dashboard prototype |
| Attendance | Dedicated attendance navigation and dashboard presence | Consistent with current prototype; NEXUS should inform detailed register states and permissions |
| Alumni | Grade 9 leaver archiving with links to long-term academic and finance records | Valuable Kenyan JSS continuity feature |
| Timetable and communication | Timetable, AI SMS Centre, and parent-facing concepts appear in the navigation | Candidate later-phase modules |

## Screens captured

The archive includes representative screens for:

- School dashboard branded for Ebunangwe Junior School.
- Assessments and CBC 8-level marklists.
- Teacher subject and grade allocations.
- Users and credential register.
- School profile and report-card configuration.
- Fees, payments, and accountability.
- Alumni archives.

Several numbered HTML files are duplicates or near-duplicates of these views, indicating repeated captures rather than separate application implementations.

## Important security and architecture observations

NEXUS presents a useful permission model in which teachers can only view and enter marks for assigned subjects and grades. This rule should be carried into the production system as server-side authorization, not only as hidden navigation.

The captured user screen refers to a username/password directory and credential hashes. For production Kenyan SMIS, passwords must be stored only as strong one-way hashes, never displayed, exported, or recoverable by administrators. The system should additionally use session expiry, rate limiting, CSRF protection, audit events, and least-privilege role scopes.

NEXUS references Google Drive folders for alumni and exported records. This is a useful archival concept, but it should be treated as an explicit integration with access controls, retention policy, and failure handling—not as the primary database.

## Recommended incorporation into the current prototype

1. Expand **Academics** into a CBC/JSS assessment workspace with grade, learning area, term, assessment type, learner rows, 8-level achievement bands, validation, draft status, and locking/approval.
2. Add **Teacher Allocations** as a first-class administration screen and enforce subject/grade scope in backend policies.
3. Add **School Profile & Report Card Settings**, including institution identity, signatures, logo, term/year, and configurable fee visibility.
4. Add **Alumni Archives** for Grade 9 leavers while preserving immutable academic, attendance, and finance history.
5. Deepen **Finance** with voteheads, payment allocation, receipts, reconciliation, expenditure, and parent statements; later connect M-Pesa Daraja through a secure backend webhook flow.
6. Add a production **Users & Permissions** area with role templates for Super Admin, Headteacher, Deputy, Bursar, Teacher, Parent, and Student, plus an audit-log viewer.
7. Preserve the existing Schoolhouse Ledger visual system rather than copying the flatter NEXUS styling; use NEXUS primarily for workflow and data-model inspiration.

## Final assessment

NEXUS substantially improves the functional reference set for the Kenyan SMIS, especially for CBC/JSS operations and administrative controls. It should not be merged or treated as source code. The best next implementation slice is **CBC assessment entry + teacher allocation permissions + configurable report cards**, followed by the secure Laravel/API backend and M-Pesa/SMS integrations already identified in the project roadmap.
